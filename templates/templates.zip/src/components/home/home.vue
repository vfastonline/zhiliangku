<template>
  <div>
    <carousel></carousel>
    <lvsm></lvsm>
    <hcm></hcm>
    <cpm></cpm>
    <interview-main></interview-main>
    <cooperator ></cooperator>
  </div>
</template>
<style>


</style>
<script>
  export default {
    name: "home",
    data() {
      return {};
    }
  };

</script>
