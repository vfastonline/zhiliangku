<template>
  <div class="mainwidth incenter pathInfo">
    <path-info-left></path-info-left>
    <path-info-right></path-info-right>
  </div>
</template>
<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  created(){
    this.$ajax.post('tracks/path/detail').then(res=>{
      console.log(res)
    })
  }
}
</script>
<style scoped>
.pathInfo{
    padding-top:60px;
}
</style>



