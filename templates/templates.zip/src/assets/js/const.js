module.exports = (function () {
    var obj = {
        httpUrl:'http://47.93.229.122/'
    };
    return obj
  })();