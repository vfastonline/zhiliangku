export default {
  pub: {
    pageHeader: {
      demo: 'サンプル'
    }
  }
}
