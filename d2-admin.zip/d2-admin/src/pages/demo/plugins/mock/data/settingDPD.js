/* eslint-disable */
export default [
  // 字符串
  {
    title: "占位符演示",
    json: {
      "name": {
        first: '@FIRST',
        middle: '@FIRST',
        last: '@LAST',
        full: '@first @middle @last'
      }
    }
  }
]
