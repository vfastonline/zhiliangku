你可以点击每个演示卡片右上角的刷新按钮检查每次 `mock` 不同的结果

官方演示页面 [http://mockjs.com/examples.html](http://mockjs.com/examples.html)

官方 `Wiki` [https://github.com/nuysoft/Mock/wiki/Getting-Started](https://github.com/nuysoft/Mock/wiki/Getting-Started)