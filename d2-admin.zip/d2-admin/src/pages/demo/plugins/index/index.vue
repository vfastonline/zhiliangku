<template>
  <d2-container>
    <d2-page-cover
      title="插件演示"
      sub-title="D2Admin 集成了许多实用插件">
      <img src="./image/icon.png">
    </d2-page-cover>
  </d2-container>
</template>
