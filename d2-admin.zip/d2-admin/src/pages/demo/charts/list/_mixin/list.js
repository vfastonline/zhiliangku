export default {
  data () {
    return {
      pubSetting: {
        height: '100%'
      }
    }
  }
}
