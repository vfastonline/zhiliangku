<template>
  <d2-container>
    <d2-page-cover
      title="图表"
      sub-title="集成图表组件">
      <img src="./image/icon.png">
    </d2-page-cover>
  </d2-container>
</template>
