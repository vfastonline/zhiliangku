<template>
  <d2-container>
    <h1 class="d2-mt-0">该页面尚未完成组件示例搬运</h1>
    <p>D2Admin 的构建依托于由饿了么出品的 ElementUI，欲了解更多该组件的信息请查阅以下链接</p>
    <d2-link-btn title="Element" link="http://element.eleme.io/#/zh-CN"/>
  </d2-container>
</template>
