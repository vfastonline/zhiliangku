<template>
  <d2-container>
    <d2-page-cover
      title="内置组件"
      sub-title="D2Admin 为你提供了一些上手即用的组件">
      <img src="./image/icon.png">
    </d2-page-cover>
  </d2-container>
</template>
