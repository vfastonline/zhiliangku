<template>
  <d2-container>
    <template slot="header">异步加载文件</template>
    <d2-markdown :url="`${$baseUrl}markdown/demo.md`"/>
  </d2-container>
</template>
